const express = require('express')
const bodyParser = require('body-parser')

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))

const app = express()

app.use(bodyParser.json())

app.get('/ready', (_, res) => res.status(200).end())

app.post('/command/sleep', async (req, res) => {
    const { duration } = req.body

    console.log('Command sleep called')

    if (duration) {
        console.log(`'duration' = ${duration}`)
        await sleep(duration)
        return res.status(200).json({ message: `Slept for ${duration} milliseconds` }).end()
    } else {
        console.error("Missing parameter 'duration'")
        return res.status(400).json({ message: "Missing parameter 'duration'" }).end()
    }
})

app.listen(3000, () => console.log('Listening on port 3000'))
