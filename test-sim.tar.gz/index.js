const express = require('express')
const bodyParser = require('body-parser')

const app = express()

app.use(bodyParser.json())

app.get('/ready', (_, res) => res.status(200).end())

app.post('/command/test', (req, res) => {
    const { name } = req.body

    console.log('Command test called')

    if (name) {
        console.log(`'name' = ${name}`)
        return res.status(200).json({ message: `Hello, ${name}` }).end()
    } else {
        console.error("Missing parameter 'name'")
        return res.status(400).json({ message: "Missing parameter 'name'" }).end()
    }
})

app.listen(3000, () => console.log('Listening on port 3000'))
