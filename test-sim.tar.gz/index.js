const express = require("express")

const app = express()

app.get("/ready", (_, res) => res.status(200).end())

app.post("/command/test", (_, res) => res.status(200).json({message: "This is a test"}).end())

app.listen(3000, () => console.log("Listening on port 3000"))
